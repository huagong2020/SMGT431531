local current_footer = "SGMT 431 · Lecture 7 · Overview"

function Header(header)
  if header.level ~= 2 then
    return header
  end

  if header.classes:includes("section-slide") then
    local section_title = pandoc.utils.stringify(header.content)
    current_footer = "SGMT 431 · Lecture " .. section_title
  end

  local escaped = current_footer
    :gsub("&", "&amp;")
    :gsub("<", "&lt;")
    :gsub(">", "&gt;")

  return { header, pandoc.RawBlock("html", '<div class="section-footer">' .. escaped .. '</div>') }
end
